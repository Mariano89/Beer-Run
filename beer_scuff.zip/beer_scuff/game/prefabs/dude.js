'use strict';

var Dude = function(game, x, y, frame) {
  Phaser.Sprite.call(this, game, x, y, 'dude', frame);

  this.game.physics.arcade.enable(this);

  this.body.gravity.y = 720;
  this.body.collideWorldBounds = false;
  this.outofBoundsKill = true;

  this.animations.add('jump', [1], 10, true );
  this.animations.add('run', [0, 1, 2, 3], 8, true);

  this.lives = 3;

};

Dude.prototype = Object.create(Phaser.Sprite.prototype);
Dude.prototype.constructor = Dude;
Dude.prototype.update = function() {
};
Dude.prototype.jump = function(){
  this.body.velocity.y = -400;
}

module.exports = Dude;

