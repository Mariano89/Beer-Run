'use strict';

var Dude = require('../prefabs/dude');
var Ground = require('../prefabs/ground');
var Beer = require('../prefabs/beer');
var Keg = require('../prefabs/keg');
var PausePanel = require('../prefabs/pausePanel');

function Play() {}
Play.prototype = {
  create: function() {
    this.game.physics.startSystem(Phaser.Physics.ARCADE);
    this.game.physics.arcade.gravity.y = 750;

    //background
    this.background = this.game.add.tileSprite(0, -35, 653, 352, 'background');
    this.background.autoScroll(-100, 0);
    this.background.scale.setTo(2, 2);

    //ground 
    this.groundGroup = this.game.add.group();

    this.initial_ground = new Ground(this.game, 0, this.game.world.height - 64, 300, 150);
    this.initial_ground.scale.setTo(4.5, 3);
    this.game.add.existing(this.initial_ground);

    this.groundGenerator = this.game.time.events.loop(Phaser.Timer.SECOND * 2, this.generateGrounds, this);
    this.groundGenerator.timer.start();

    //player 
    this.player = new Dude(this.game, 500, 0)
    this.game.add.existing(this.player);

    //beer 
    this.beers = this.game.add.group();

    //keg
    this.kegs = this.game.add.group();

    //game controls
    this.jumpKey = this.input.keyboard.addKey(Phaser.Keyboard.SPACEBAR);
    // this.pauseKey = this.game.input.keyboard.addKey(32);

    // makes spacebar not scroll down 
    this.game.input.keyboard.addKeyCapture([Phaser.Keyboard.SPACEBAR]);

    //pause button
    this.btnPause = this.game.add.button(1150, 40, 'pause-btn', this.pauseGame, this);
    this.btnPause.anchor.setTo(0.5,0.5);
    this.btnPause.alpha = 1;

    //pause panel
    this.pausePanel = new PausePanel(this.game);
    this.game.add.existing(this.pausePanel);

    this.initGame();
  },
  update: function() {
    this.checkCollisions();
    this.player.body.velocity.x = 400;

    //player 
    if (this.jumpKey.isDown && this.player.body.touching.down)
    {
      this.game.sound.play('dudeJump', 1, 0, false, false);
      this.player.body.velocity.y = -550;
    }
    else if(!this.player.body.touching.down){
      this.player.animations.play('jump');
      this.player.body.velocity.x = 0; 
    }
    else{
      this.player.animations.play('run');
    };
  },
  checkCollisions: function(){
    //collision between elements

    //landing
    this.game.physics.arcade.collide(this.player, this.initial_ground);
    this.game.physics.arcade.collide(this.beers, this.initial_ground);

    this.game.physics.arcade.collide(this.player, this.groundGroup);
    this.game.physics.arcade.collide(this.beers, this.groundGroup);

    //collection
    this.game.physics.arcade.overlap(this.player, this.beers, this.collectBeer, null, this);
    this.game.physics.arcade.overlap(this.player, this.kegs, this.collectKegs, null, this);
  },
  generateGrounds: function() {  
    // console.log(this.game.world.height - 64);
    var randomY = this.game.rnd.integerInRange(440, 520);
    var randGround = this.groundGroup.getFirstExists(false);
      if(!randGround) {
        randGround = new Ground(this.game, 1200, randomY, 300, 150);
        randGround.scale.setTo(1.5, 10);
        this.groundGroup.add(randGround);
      }
      randGround.reset(1200, randomY);
  },
  generateBeers: function(){
    // console.log('beer');
    var beer = new Beer(this.game, 1199, 300)
    this.beers.add(beer);
  },
  generateKegs: function(){
    // console.log('keg');
    var keg = new Keg(this.game, 1199, 300)
    this.beers.add(keg);
  },
  collectBeer: function(player, beer) {
    // Removes the beer from the screen
    beer.kill();
    //  Add and update the score
    // score += 1;
    // scoreText.text = 'Score: ' + score;
  },
  collectKeg: function(player, keg) {
    // Removes the beer from the screen
    keg.kill();
    //  Add and update the score
    // score += 5;
    // scoreText.text = 'Score: ' + score;
  },
  killDude: function(player){
    this.player.lives--;
  },
  initGame: function(){
    //creates beer at intervals
    this.beerGenerator = this.game.time.events.loop(Phaser.Timer.SECOND * 0.6, this.generateBeers, this);
    this.beerGenerator.timer.start();

    //creates kegs at intervals
    this.kegGenerator = this.game.time.events.loop(Phaser.Timer.SECOND * 2.6, this.generateKegs, this);
    this.kegGenerator.timer.start();

    this.playGame();
  },
  playGame: function(){
    if(this.game.paused){
      this.game.paused = false;

      // Resume generators
      this.beerGenerator.timer.resume();
      this.kegGenerator.timer.resume();

      // Show pause button
      // this.game.add.tween(this.btnPause).to({alpha:1}, 1000, Phaser.Easing.Exponential.Out, true);
      this.pausePanel.alpha = 0;
    };
  },
  pauseGame: function(){
    if(!this.game.paused){
      console.log(this.game.paused);
      this.game.paused = true;

      // Pause generators
      this.beerGenerator.timer.pause();
      this.kegGenerator.timer.pause();

      // Hide pause button
      // this.game.add.tween(this.btnPause).to({alpha:0}, 1000, Phaser.Easing.Exponential.Out, true);
      this.btnPause.alpha = 0;

      // if(!this.gameover){
        // Show pause panel
        this.pausePanel.show();
      // };
      console.log(this.pausePanel.show());
      // console.log(this.gameover);
    };
  },
  unpauseGame: function(){
    if(this.game.paused){
      this.game.paused = false;

      // Resume generators
      this.beerGenerator.timer.resume();
      this.kegGenerator.timer.resume();

      // Show pause button
      this.game.add.tween(this.btnPause).to({alpha:1}, 1000, Phaser.Easing.Exponential.Out, true);
    };
  },

  clickListener: function() {
    // this.game.state.start('gameover');
  }
};

module.exports = Play;

